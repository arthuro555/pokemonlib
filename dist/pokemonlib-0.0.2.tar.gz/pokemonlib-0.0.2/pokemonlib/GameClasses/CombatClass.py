class Combat:
    def __init__(self, team_one, team_two):
        self.team1 = team_one
        self.team2 = team_two

    def damage_calculation(self, pokemon_attacking, pokemon_defending):
        pass

