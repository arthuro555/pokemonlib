# Encryption. DON'T MODIFY AFTER FIRST RELEASE OR SAVES WON'T WORK ANYMORE!!!
SALT = "HbhlhvHVJHGvkGvkgCVkgCKGckgtcRsus4i87t97fryZdxikTcirsrTFfsr6X"  # Make a random value
ENCRYPTION_PASSWORD = "password"  # Make whatever you want with this.

# Saves
POKEMON_LIKE_SAVES = True  # This option enables saves working the same way as in pokemon games, aka 1 save file that
# Gets overridden each time you save
ANTI_CHEAT = False  # Use only if you REALLY don't want cheaters. This will add variables to __builtins__ to make more
# checks on save files before loading them. It's highly inadvisable to touch at __builtins__ normally.
ENABLE_AUTO_ENCRYPTION_FOR_SAVE_FILES = True  # Unless you want to mess around with your save file let it on True.
