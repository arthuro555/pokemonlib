class IdNotReferenced(Exception):
    pass


class InvalidPokemonData(Exception):
    pass


class NotAPokemon(Exception):
    pass


class InvalidInput(Exception):
    pass


class ListFull(Exception):
    pass
