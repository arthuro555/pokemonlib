class IdNotReferenced(Exception):
    pass


class InvalidPokemonData(Exception):
    pass
