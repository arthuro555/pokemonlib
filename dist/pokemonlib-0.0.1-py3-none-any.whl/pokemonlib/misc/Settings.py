SALT = "HbhlhvHVJHGvkGvkgCVkgCKGckgtcRsus4i87t97fryZdxikTcirsrTFfsr6X"
ENCRYPTION_PASSWORD = "password"